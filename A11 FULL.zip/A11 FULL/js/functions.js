$(document).ready(function() {
    $('#analiza').click(function() {
        var osoba1s = "",
            osoba2s = ""; //osoba 1,2 suma string
        var osoba1i = 0,
            osoba2i = 0; //osoba 1,2 suma integer
        //npr. ako smo uneli za osobu1 datum 4.5.2001 a za osobu2 9.10.2001.
        var osoba1niz = $('#prvidatum').val().split('.'); // osoba1niz[0] = 4,osoba1niz[1] = 5, osoba1niz[2] = 2001
        var osoba2niz = $('#drugidatum').val().split('.'); //osoba2niz[0] = 9,osoba1niz[1] = 10,osoba1niz[2] = 2001
        for (var i = 0; i < osoba1niz.length; i++)
            osoba1s += osoba1niz[i]; // osoba1s = 452001
        for (var j = 0; j < osoba2niz.length; j++)
            osoba2s += osoba2niz[j]; // osoba2s = 9102001
        osoba1i = parseInt(osoba1s); // osoba1i = 452001 - pretvoreno u int
        osoba1i = zbircifara(zbircifara(osoba1i)); // prvi put 4+5+2+0+0+1 = 12, drugi put 1+2 = 3
        osoba2i = parseInt(osoba2s); // osoba2i = 9102001 - pretvoreno u int
        osoba2i = zbircifara(zbircifara(osoba2i)); // prvi put 9+1+0+2+0+0+1 = 13, drugi put 1+3 = 4
        var podudarnost = 0;
        if (osoba1i > osoba2i) // 3>4 uslov nije tacan
            podudarnost = parseFloat(osoba2i / osoba1i).toFixed(2) * 100;
        else
            podudarnost = parseFloat(osoba1i / osoba2i).toFixed(2) * 100; // 3/4*100 = 75
        document.getElementById("prikaz").value = podudarnost + "%"; // prikazi u tekst polje (75%)
        $('#prvoime').val('');
        $('#drugoime').val('');
        $('#prvidatum').val('');
        $('#drugidatum').val('');
    });
});

function zbircifara(osoba) {
    var osobastr = osoba.toString();
    var sum = 0;
    for (var i = 0; i < osobastr.length; i++) {
        sum += parseInt(osobastr.charAt(i), 10);
    }
    return sum;
}