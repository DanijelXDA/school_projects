#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main()
{
    char string1[50] = "Ovo je string!", string2[50];
    int n;
    char unos, unos2[5];

    printf("\nDuzina stringa bez zavrsnog karaktera je: %d\n", strlen(string1));
    printf("\nKopiranje stringa: %s\n", strcpy(string2, string1));
    printf("\nPoredjenje dva stringa: %s\n", (n = strcmp(string1, string2) == 0) ? "JEDNAKI" : "NISU JEDNAKI");

    // ctype
    printf("\nUnesite jedno slovo: ");
    unos = getchar();

    printf("\nSlovo je: %s\n", (isupper(unos)) ? "VELIKO" : "MALO");

    fflush(stdin);
    printf("\nUnesite jedan ceo broj: ");
    gets(unos2);

    printf("\nString u ceo broj: %d\n", atoi(unos2));
    printf("\nString u realan broj: %f\n", atof(unos2));

    return 0;
}
