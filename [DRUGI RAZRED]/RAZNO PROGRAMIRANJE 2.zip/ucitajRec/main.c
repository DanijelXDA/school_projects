#include <stdio.h>
#include <string.h>
#include <ctype.h>

void ucitajRec(char *rec)
{
    int i = 0, c;

    while(!isspace(c = getchar()))
        rec[i++] = c;

    rec[i] = '\0';
}

void ispisiRec(char *rec)
{
    int i = 0;

    while(i < strlen(rec))
    {
        putchar(rec[i]);
        i++;
    }
}

int main()
{
    char rec[25];

    puts("Unesite jednu rec: ");
    ucitajRec(rec);

    ispisiRec(rec);



    return 0;
}
