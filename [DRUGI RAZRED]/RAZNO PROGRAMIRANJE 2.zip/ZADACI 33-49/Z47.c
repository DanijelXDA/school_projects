#include <stdio.h>

/*
Задатак 47: Написати функцију void izmeni(int *broj) која за параметар има
адресу једне целобројне променљиве.
Увећати вредност те променљиве за 150.
Приказати вредност променљиве пре и после позива функције izmeni( ) у
главном програму.
*/
void izmeni(int *broj) { *broj += 150; }


int main(void)
{
    int x;

    printf("Unesite jedan ceo broj: ");
    scanf("%d", &x);

    printf("\nPre poziva funckcije izmeni()\nx = %d\n", x);
    izmeni(&x);
    printf("\nPosle poziva funckcije izmeni()\nx = %d\n", x);

    return 0;
}
