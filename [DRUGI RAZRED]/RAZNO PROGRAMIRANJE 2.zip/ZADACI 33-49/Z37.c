#include <stdio.h>

/*
Задатак 37: Написати функцију која рачуна производ бројева од од 1 до N.
Број N уноси корисник и он се прослеђује у позиву функције као њен параметар.
*/
int proizvod1DoN(int n)
{
    int i, proizvod = 1;

    for(i = 1; i <= n; i++)
        proizvod *= i;

    return proizvod;
}

int main(void)
{
    int n;

    printf("Unesite broj N: ");
    scanf("%d", &n);

    printf("\nProizvod brojeva od 1 do %d iznosi: %d", n, proizvod1DoN(n));

    return 0;
}
