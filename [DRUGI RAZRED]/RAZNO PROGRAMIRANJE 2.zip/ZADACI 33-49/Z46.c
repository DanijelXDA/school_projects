#include <stdio.h>

/*
Задатак 46: Написати функцију која за параметар има један цео троцифрен
број.
Затим функција исписује тај цео број, па у новом реду исписује цифре тог броја
понаособ раздвојене једним размаком.
*/
void ispisiTrocifreniBroj(int broj)
{
    printf("\nCeo broj: %d\n", broj);
    printf("\nPrva cifra: %d", broj / 100);
    printf("\nDruga cifra: %d", (broj / 10) % 10);
    printf("\nTreca cifra: %d\n\n", (broj % 100) % 10);
}


int main(void)
{
    int x;

    printf("Unesite jedan ceo broj: ");
    scanf("%d", &x);

    ispisiTrocifreniBroj(x);

    return 0;
}
