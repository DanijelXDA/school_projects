#include <stdio.h>

/*
Задатак 44: Написати програм који приказује ПРЕНОС ПАРАМЕТАРА ПО
ВРЕДНОСТИ.
Програм реализовати помоћу функције која користи својство преноса
параметара по вредности, тј. у њеном позиву у main( ) фунцији прослеђене су
две променљиве по вредности.
Унутар функције променити вредности прослеђених променљивих.
Које су вредности променљивих након извршавања функције?
*/
void prenosParametaraPoVrednosti(int x, int y) // ne menjaju se vrednosti
{
    x = 25;
    y = 55;
}


int main(void)
{
    int x, y;

    printf("Unesite dva cela broja: ");
    scanf("%d %d", &x, &y);

    printf("\nPre poziva funckcije prenosParametaraPoVrednosti()\nx = %d, y = %d\n", x, y);
    prenosParametaraPoVrednosti(x, y);
    printf("\nPosle poziva funckcije prenosParametaraPoVrednosti()\nx = %d, y = %d\n", x, y);

    return 0;
}
