#include <stdio.h>

/*
Задатак 42: Написати функцију која рачуна запремину коцке.
Параметар функције је ивица коцке коју уноси корисник и која се прослеђује
у позиву функције.
*/
float zapreminaKocke(float a) { return a * a * a; }


int main(void)
{
    int a;

    printf("Unesite stranicu a ");
    scanf("%d", &a);

    printf("\nZapremina kocke iznosi: %f.", zapreminaKocke(a));

    return 0;
}
