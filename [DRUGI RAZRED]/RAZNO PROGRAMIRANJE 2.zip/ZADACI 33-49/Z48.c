#include <stdio.h>

/*
Задатак 48: Написати функцију која рачуна факторијел броја N.
Број N уноси корисник и он се прослеђује као параметар функције.
*/
int faktorijel(int n)
{
    if(n <= 1)
        return 1;
    else
        return n * faktorijel(n - 1);
}


int main(void)
{
    int x;

    printf("Unesite jedan ceo broj: ");
    scanf("%d", &x);

    printf("\nFaktorijel %d! = %d\n", x, faktorijel(x));

    return 0;
}
