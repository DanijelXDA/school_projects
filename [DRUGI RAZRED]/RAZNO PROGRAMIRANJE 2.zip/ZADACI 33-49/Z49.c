#include <stdio.h>

/*
Задатак 49: Написати функцију која на основу једног целог броја који уноси
корисник, рачуна и приказује фибоначијев низ.
*/
int fibonaci(int n)
{
    if(n == 0 || n == 1)
        return n;
    else
        return fibonaci(n - 1) + fibonaci(n - 2);
}


int main(void)
{
    int x;

    printf("Unesite jedan ceo broj: ");
    scanf("%d", &x);

    printf("\nFibonaci(%d) = %d\n", x, fibonaci(x));

    return 0;
}
