#include <stdio.h>

/*
Задатак 45: Написати програм који приказује ПРЕНОС ПАРАМЕТАРА ПО
АДРЕСИ.
Програм реализовати помоћу функције која користи својство преноса
параметара по адреси, тј. у њеном позиву у main( ) фунцији прослеђене су две
адресе променљивих.
Унутар функције променити вредности прослеђених променљивих.
Које су вредности променљивих након извршавања функције?
*/
void prenosParametaraPoAdresi(int *x, int *y) // menjaju se vrednosti
{
    *x = 25;
    *y = 55;
}


int main(void)
{
    int x, y;

    printf("Unesite dva cela broja: ");
    scanf("%d %d", &x, &y);

    printf("\nPre poziva funckcije prenosParametaraPoAdresi()\nx = %d, y = %d\n", x, y);
    prenosParametaraPoAdresi(&x, &y);
    printf("\nPosle poziva funckcije prenosParametaraPoAdresi()\nx = %d, y = %d\n", x, y);

    return 0;
}
