#include <stdio.h>

/*
Задатак 39: Написати функције које рачунају обим и површину
једнакостраничног троугла.
Параметар обе функције је страница троугла коју уноси корисник и која се
прослеђује у позиву функције.
*/
float obimJednakostranicnogTrougla(float a) { return 3.0 * a; }
float povrsinaJednakostranicnogTrougla(float a) { return (a * a * 1.73) / 4.0 ; }


int main(void)
{
    int a;

    printf("Unesite stranicu a: ");
    scanf("%d", &a);

    printf("\nObim jed. trougla iznosi: %f.", obimJednakostranicnogTrougla(a));
    printf("\nPovrsina jed. trougla iznosi: %f.", povrsinaJednakostranicnogTrougla(a));

    return 0;
}
