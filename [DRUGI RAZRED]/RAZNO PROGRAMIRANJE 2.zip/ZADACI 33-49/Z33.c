#include <stdio.h>

/*
Задатак 33: Написати функцију чији су аргументи два цела броја.
Функција треба да сабере та два броја и да врати збир тих бројева.
*/
int saberi(int x, int y) { return x + y; }


int main(void)
{
    int br1, br2;

    printf("Unesite dva cela broja: ");
    scanf("%d %d", &br1, &br2);

    printf("\nSuma iznosi: %d", saberi(br1, br2));

    return 0;
}
