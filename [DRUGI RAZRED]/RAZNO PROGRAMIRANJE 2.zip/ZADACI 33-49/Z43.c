#include <stdio.h>

/*
Задатак 43: Написати функцију која рачуна запремину квадра.
Параметри обе функције су ивице квадра које уноси корисник и које се
прослеђују у позиву функције.
*/
float zapreminaKvadra(float a, float b, float c) { return a * b * c; }



int main(void)
{
    float a, b, c;

    printf("Unesite stranice a, b i c: ");
    scanf("%f %f %f", &a, &b, &c);

    printf("\nZapremina kvadra iznosi: %f.", zapreminaKvadra(a, b, c));

    return 0;
}
