#include <stdio.h>

// Задатак 34: Написати функцију која ће да помножи два реална броја.
float pomnozi(float x, float y) { return x * y; }


int main(void)
{
    float br1, br2;

    printf("Unesite dva realna broja: ");
    scanf("%f %f", &br1, &br2);

    printf("\nProizvod iznosi: %f", pomnozi(br1, br2));

    return 0;
}
