#include <stdio.h>

/*
Задатак 38: Написати функције које рачунају обим и површину квадрата.
Параметар обе функције је страница квадрата коју уноси корисник и која се
прослеђује у позиву функције.
*/
float obimKvadrata(float a) { return 4.0 * a; }
float povrsinaKvadrata(float a) { return a * a; }

int main(void)
{
    int a;

    printf("Unesite stranicu a: ");
    scanf("%d", &a);

    printf("\nObim kvadrata iznosi: %f.", obimKvadrata(a));
    printf("\nPovrsina kvadrata iznosi: %f.", povrsinaKvadrata(a));

    return 0;
}
