#include <stdio.h>

/*Задатак 35: Написати функцију која рачуна збир квадрата бројева од 1 до N.
Број N уноси корисник и он се прослеђује у позиву функције као њен параметар.
*/
int zbirKvadrata(int n)
{
    int i, zbir = 0;

    for(i = 1; i <= n; i++)
        zbir += i * i;

    return zbir;
}

int main(void)
{
    int n;

    printf("Unesite broj N: ");
    scanf("%d", &n);

    printf("\nZbir kvadrata brojeva od 1 do %d iznosi: %d", n, zbirKvadrata(n));

    return 0;
}
