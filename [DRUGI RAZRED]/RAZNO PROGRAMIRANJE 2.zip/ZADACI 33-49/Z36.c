#include <stdio.h>

/*
Задатак 36: Написати функцију која рачуна збир бројева од од 1 до N.
Број N уноси корисник и он се прослеђује у позиву функције као њен параметар.
*/
int zbir1DoN(int n)
{
    int i, zbir = 0;

    for(i = 1; i <= n; i++)
        zbir += i;

    return zbir;
}

int main(void)
{
    int n;

    printf("Unesite broj N: ");
    scanf("%d", &n);

    printf("\nZbir brojeva od 1 do %d iznosi: %d", n, zbir1DoN(n));

    return 0;
}
