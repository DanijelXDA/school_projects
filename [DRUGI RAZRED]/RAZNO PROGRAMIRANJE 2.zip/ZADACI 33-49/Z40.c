#include <stdio.h>

/*
Задатак 40: Написати функције које рачунају обим и површину правоуганика.
Параметри обе функције су странице правоугаоника које уноси корисник и које
се прослеђују у позиву функције.
*/
float obimPravougaonika(float a, float b) { return 2.0 * (a + b); }
float povrsinaPravougaonika(float a, float b) { return a * b; }


int main(void)
{
    int a, b;

    printf("Unesite stranice a i b: ");
    scanf("%d %d", &a, &b);

    printf("\nObim pravougaonika iznosi: %f.", obimPravougaonika(a, b));
    printf("\nPovrsina pravougaonika iznosi: %f.", povrsinaPravougaonika(a, b));

    return 0;
}
