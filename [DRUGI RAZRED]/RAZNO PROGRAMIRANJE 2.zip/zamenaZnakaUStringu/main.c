#include <stdio.h>
#include <string.h>

#define USPESNO 1
#define NEUSPESNO -1

int zameniSlovoUStringu(char string[], int duzina, char izbaci, char ubaci)
{
    int i, uspesno = 0;

    for(i = 0; i < duzina; i++)
    {
        if(string[i] == izbaci)
        {
            string[i] = ubaci;
            uspesno++;
        }
    }

    return (uspesno == 0) ? NEUSPESNO : USPESNO;
}

int main()
{
    char string[50] = "Ovo je c kurs i sve je cakum pakum!";

    int usp = zameniSlovoUStringu(string, strlen(string), 'c', '-');

    if( usp == 1 )
    {
        printf("\nNakon izbacivanja: %s\n", string);
    }
    else
    {
        printf("\nU stringu nema zamena!\n");
    }

    return 0;
}
