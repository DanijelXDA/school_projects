﻿function fun(sediste) {
    document.getElementById("broj").value = sediste;
}

function funkcija() {
    var x = document.getElementById("broj").value;

    if (x == "")
        window.alert("Niste uneli broj sedista");
    else
    if (document.getElementById("sediste" + x).getAttribute("src") == "slike/busoff.jpg")
        document.getElementById("sediste" + x).src = "slike/buson.png"
    else
        window.alert("Sediste je rezervisano!");
}